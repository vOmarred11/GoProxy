# GoProxy (broken and outdated)

### GoProxy is a man-in-the-middle (MITM) proxy, it works by intercepting and modifying packets between the client and the server.

### How to use

To use you must have Go version 1.9 or greater installed.

1. clone the project: `go get github.com/InfinityGamers/GoProxy`
2. navigate to the clone directory
3. install dependencies with `go install`
4. compile it and run it
# Example use cases
### In this case it was mainly used to have advantages in Minecraft.

## KILLAURA CHEATS
[![IMAGE ALT TEXT HERE](https://img.youtube.com/vi/w4J-HzICmWc/0.jpg)](https://www.youtube.com/watch?v=w4J-HzICmWc)
## SPEED/KILLAURA/FLYING CHEATS
[![IMAGE ALT TEXT HERE](https://img.youtube.com/vi/h43zbAWX7zQ/0.jpg)](https://www.youtube.com/watch?v=h43zbAWX7zQ)
## AUTOMATED MINECRAFT PVP BOT
[![IMAGE ALT TEXT HERE](https://img.youtube.com/vi/2NqTOBOu0-Y/0.jpg)](https://www.youtube.com/watch?v=2NqTOBOu0-Y)

### Notices

This will not work on encrypted servers such as LBSG, Mineplex, etc. <br><br>
At the moment it has very simple features, but I will continue on updating as much as I can. <br>