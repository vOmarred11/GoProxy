package main

import (
	"github.com/infinitygamers/goproxy"
)

func main()  {
	mcpeproxy.StartProxy()
}
